% Calcula a probababilidade de um evento acontecer k vezes em n tentativas por simulação
% N = número de vezes a repetir a experiência
% p = probabilidade analítica do evento elementar acontecer
function[probSimulacao] = f(N, p, k, n)
	lancamentos = rand(n,N) < p;
	sucessos= sum(lancamentos)==k;
	probSimulacao= sum(sucessos)/N;
end