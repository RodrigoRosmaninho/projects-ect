% Função distribuicao acumulada
fx = cumsum([0,px,0]);
subplot(1,2,1)
stairs(0:11,fx)
axis([0,11,0,1.1]);
xlabel("x");
ylabel("f_x(x)");