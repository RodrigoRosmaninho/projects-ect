% valor esperado
x = 0:4;
px = [0 0 0 0 0];
index = 0;
for index  = 0:4
  px(index + 1) = f(1e5,0.5,index,4);
end
EX = sum(x.*px)
var = sum(((x-EX).^2).*px)
desvio = sqrt(var)