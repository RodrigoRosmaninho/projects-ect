l = 15; # lambda
probPoisson = 1;
for k = 0:10
  probPoisson = probPoisson - ((l**k).*(e**(-l)))/factorial(k);
endfor
probPoisson