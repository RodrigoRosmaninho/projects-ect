% Função massa probabilidade
x = [5 50 100];
px = [9/10 9/100 1/100];
subplot(1,2,1)
stem(x,px)
axis([0,100,0,9/10]);
xlabel("x");
ylabel("p_x(x)");