probSimulacao = f(1e5,0.3,0,5) + f(1e5,0.3,1,5) + f(1e5,0.3,2,5)
probAnalitica = m(0.3,0,5) + m(0.3,1,5) + m(0.3,2,5)