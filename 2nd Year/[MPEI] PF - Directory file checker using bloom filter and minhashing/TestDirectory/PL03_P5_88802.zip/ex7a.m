k = 0;
l = 15; # lambda
probPoisson = ((l**k).*(e**(-l)))/factorial(k)