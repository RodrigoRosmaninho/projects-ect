a = 0;
b = 10;
x1 = 7;
x2 = b;

probAnalitica = (x2 - x1)/(b - a)

tentativas = a+rand(1,1e5)*(b-a) > 7;
probSimulacao = sum(tentativas)/1e5