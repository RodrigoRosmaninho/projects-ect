disp("S={5,5,5,5,5,...(85*5),50,50,50,50,50,50,50,50,50,100}")
disp("P(retirar nota de 5) = 9/10\nP(retirar nota de 50) = 9/100\nP(retirar nota de 100) = 1/100")