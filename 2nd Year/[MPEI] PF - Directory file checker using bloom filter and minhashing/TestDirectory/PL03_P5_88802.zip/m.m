% Calcula a probababilidade de um evento acontecer k vezes em n tentativas através da dispersão binomial
% p = probabilidade analítica do evento elementar acontecer
function[probAnalitica] = m(p, k, n)
	probAnalitica= factorial(n)/(factorial(n-k)*factorial(k))*p^k*(1-p)^(n-k);
end