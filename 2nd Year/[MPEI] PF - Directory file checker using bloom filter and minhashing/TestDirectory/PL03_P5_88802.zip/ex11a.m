media = 14;
desvio = 2;

tentativas = media+randn(1,1e5)*desvio;
tentativas = tentativas <= 16 & tentativas >=12;
probSimulacao = sum(tentativas)/1e5