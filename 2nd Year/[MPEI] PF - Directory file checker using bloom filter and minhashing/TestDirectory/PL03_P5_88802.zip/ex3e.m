alinea1 = m(0.5,2,4) + m(0.5,3,4) + m(0.5,4,4);
alinea2 = m(0.5,0,4) + m(0.5,1,4);
alinea3 = m(0.5,1,4) + m(0.5,2,4) + m(0.5,3,4);

printf("P(pelo menos 2 coroas em 4 lançamentos) = %u \n", alinea1)
printf("P(até 1 coroa em 4 lançamentos) = %u \n", alinea2)
printf("P(entre 1 e 3 coroas em 4 lançamentos) = %u \n", alinea3)