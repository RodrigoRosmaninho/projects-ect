disp("S={5,5,5,5,5,...(85*5),50,50,50,50,50,50,50,50,50,100}")
disp("P(retirar uma nota especifica) = 1/100")