soma_de_probabilidades = 0;
for x = 1:4
  soma_de_probabilidades = soma_de_probabilidades + (x+5)/30;
endfor
soma_de_probabilidades   # print
if soma_de_probabilidades == 1.0000
  printf("A função pode representar a variável aleatória!\n")
endif