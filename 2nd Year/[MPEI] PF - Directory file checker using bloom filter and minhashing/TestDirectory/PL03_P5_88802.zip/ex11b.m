media = 14;
desvio = 2;

tentativas = media+randn(1,1e5)*desvio;
tentativas = tentativas <= 18 & tentativas >=10;
probSimulacao = sum(tentativas)/1e5