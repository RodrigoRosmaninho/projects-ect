probBinomial = m(0.001,7,8000)
probPoisson = p(0.001,7,8000)