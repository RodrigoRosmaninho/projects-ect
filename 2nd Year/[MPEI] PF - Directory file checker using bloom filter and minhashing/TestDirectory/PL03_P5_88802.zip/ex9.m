k = 0;
l = 1; # lambda
probPoisson = ((l**k).*(e**(-l)))/factorial(k);
probPoisson = 1 - probPoisson