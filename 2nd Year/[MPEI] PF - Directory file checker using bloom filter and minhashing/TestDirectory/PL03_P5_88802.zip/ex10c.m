a = 0;
b = 10;
x1 = 1;
x2 = 6;

probAnalitica = (x2 - x1)/(b - a)

tentativas = a+rand(1,1e5)*(b-a);
tentativas = tentativas < 6 & tentativas > 1;
probSimulacao = sum(tentativas)/1e5