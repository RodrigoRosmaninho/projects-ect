% A distribuição da variável aleatória X é do tipo discreto binomial.
% A sua função massa de probabiliddade é: P(x) = factorial(4)/(factorial(4-x)*factorial(x))*0.5^x*(1-0.5)^(4-x)

printf("P(0 coroas em 4 lançamentos) = %u \n", factorial(4)/(factorial(4-0)*factorial(0))*0.5^0*(1-0.5)^(4-0))
printf("P(1 coroas em 4 lançamentos) = %u \n", factorial(4)/(factorial(4-1)*factorial(1))*0.5^1*(1-0.5)^(4-1))
printf("P(2 coroas em 4 lançamentos) = %u \n", factorial(4)/(factorial(4-2)*factorial(2))*0.5^2*(1-0.5)^(4-2))
printf("P(3 coroas em 4 lançamentos) = %u \n", factorial(4)/(factorial(4-3)*factorial(3))*0.5^3*(1-0.5)^(4-3))
printf("P(4 coroas em 4 lançamentos) = %u \n", factorial(4)/(factorial(4-4)*factorial(4))*0.5^4*(1-0.5)^(4-4))

% Corresponde ao observado na alinea a)