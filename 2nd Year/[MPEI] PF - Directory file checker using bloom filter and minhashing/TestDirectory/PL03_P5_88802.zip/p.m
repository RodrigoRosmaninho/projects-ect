% Calcula a probababilidade de um evento acontecer k vezes em n tentativas através da distribuição de Poisson
% p = probabilidade analítica do evento elementar acontecer
function[probPoisson] = p(p, k, n)
  l = n.*p; # lambda
	probPoisson = ((l**k).*(e**(-l)))/factorial(k);
end